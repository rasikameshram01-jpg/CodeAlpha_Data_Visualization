# CodeAlpha Data Visualization — E-Commerce Sales Analysis

## Overview
This Jupyter Notebook explores e-commerce sales data using Python. It includes data cleaning, summary metrics, visualizations, and automatically generated findings.

## Visualizations
- Total sales by category
- Monthly sales trend
- Profit by region
- Sales vs. profit scatter plot
- Sales distribution
- Interactive product sales chart (Plotly)
- Correlation heatmap

## Tech Stack
Python, Pandas, NumPy, Matplotlib, Seaborn, Plotly, Jupyter Notebook.

## Run locally
1. Install Python and Jupyter Notebook.
2. Install dependencies:
   ```bash
   pip install pandas numpy matplotlib seaborn plotly jupyter
   ```
3. Place `sales.csv` beside `Data_Visualization.ipynb`, then open the notebook and run cells in order.
4. If `sales.csv` is absent, the notebook creates a small fictional sample dataset automatically.

## Dataset format
Expected columns:
- `Order Date`
- `Product Name`
- `Category`
- `Region`
- `Sales`
- `Profit`
- Optional: `Quantity`

The sample data is fictional and for demonstration only. Replace it with a properly sourced dataset before making real-world claims.

## Repository structure
```text
CodeAlpha_Data_Visualization/
├── Data_Visualization.ipynb
├── README.md
├── requirements.txt
├── .gitignore
└── visualizations/
```
